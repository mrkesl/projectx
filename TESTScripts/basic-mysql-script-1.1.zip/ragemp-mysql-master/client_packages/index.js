require("login.js");

mp.gui.chat.show(true);
mp.gui.chat.activate(false);