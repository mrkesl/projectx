Version 0.3 - March 22th, 2018

Yes there are lack of features or some bugs, 0.1. Make bug reports/suggestions if you have any.
**Note that your current edit is autosaved every 30 seconds. To load it call '/mload autosave'.

(Yes I know commands throw "Command not found". Ignore it for now)

Installation:

Drop the "MapEditor" folder inside the "client_packages" folder into your own "client_packages" folder.
Merge the index.js file found inside "client_packages" with your own.

Drop the "MapEditor" folder inside the "packages" folder into your own "packages" folder.

Usage:

To start/exit the editor press F2.
Press 1 for Selector Mode (You can click on objects, or click off to deselect)
Press 2 for Object Placement Mode
Press 3 for Adjustment Mode

WASD to move around. E and Q to move up and down.
Shift to speed up movement, control to slow down movement.
Ctrl + Z to undo object creation, Ctrl + Y to redo it. This only applies to object creation for now.

Controls are defined on the screen for you. Mostly point, click, and drag.

Commands:

/msave [name] - used to save your map
/mmaps - used to see what maps you have saved in your session

/mload [name] - used to load a map (you can load/deload as many maps as you want) (it is synced)
/mdeload [name] - used to deload a map if it is loaded (not if it's in edit mode)
/mlmaps - used to see what maps are loaded
/medit [name] - used to edit a map (it will load in client sided only and you can edit it)
/mclear - used to clear your current edit

/mindx [index number] - used to set the list index since it is a huge list
/mobj [name of hash] - used to spawned a specific object by name

API:
LoadMap(name);
DeloadMap(name);
SaveMap(name, data);

DO NOT PASS IN THE "_map.json" EXTENSION. THAT IS HANDLED ON ITS OWN. ONLY PASS THE NAME YOU SAVED IT AS.
Ex. /msave map1 - will save it as map1_map.json. To load it call /mload map1 or LoadMap("map1");