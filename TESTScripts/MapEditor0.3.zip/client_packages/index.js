require("MapEditor/MapEditor.js");
require("MapEditor/object_data.js");
require("MapEditor/Natives.js");