﻿namespace Admin
{
    public class AdminAccount
    {
        public string SocialClub { get; set; }
        public string AdminName { get; set; }
        public byte Level { get; set; }
        public string Password { get; set; }
    }
}
