(Updated 31 MAY 2018 to RageMP instead of GT-MP)

A simple approach to an admin system for basically any server. 
Created by: -Andreas 2018

1) Drop the 'Admin' folder inside your bridge/resources folder. // Server part C#
2) Drop the 'admin' + 'index.js' instead your client_packages folder. // Client part JS
3) Remember to add the 'Admin' resource to your settings.xml file inside the bridge folder.
4) Fire up your server and you should be good to go.
