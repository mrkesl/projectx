﻿using System;

namespace WiredPlayers.model
{
    public class AdminTicketModel
    {
        public int playerId { get; set; }
        public String question { get; set; }
    }
}
