﻿using System;

namespace WiredPlayers.model
{
    public class ChannelModel
    {
        public int id { get; set; }
        public int owner { get; set; }
        public String password { get; set; }
    }
}
