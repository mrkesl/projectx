﻿using System;

namespace WiredPlayers.model
{
    public class ContactModel
    {
        public int id { get; set; }
        public int owner { get; set; }
        public int contactNumber { get; set; }
        public String contactName { get; set; }
    }
}
