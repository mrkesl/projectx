﻿namespace WiredPlayers.model
{
    public class TunningModel
    {
        public int id { get; set; }
        public int vehicle { get; set; }
        public int slot { get; set; }
        public int component { get; set; }
    }
}
