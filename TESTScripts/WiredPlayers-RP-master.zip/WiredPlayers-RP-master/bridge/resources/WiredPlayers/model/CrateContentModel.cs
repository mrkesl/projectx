﻿using System;

namespace WiredPlayers.model
{
    public class CrateContentModel
    {
        public String item { get; set; }
        public int amount { get; set; }
        public int chance { get; set; }
    }
}
