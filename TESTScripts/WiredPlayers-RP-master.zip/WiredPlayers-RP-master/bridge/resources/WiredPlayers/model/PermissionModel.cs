﻿using System;

namespace WiredPlayers.model
{
    public class PermissionModel
    {
        public int playerId { get; set; }
        public String command { get; set; }
        public String option { get; set; }
    }
}
