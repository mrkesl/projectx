﻿using GTANetworkAPI;
using System;

namespace WiredPlayers.model
{
    public class BusinessIplModel
    {
        public int type { get; set; }
        public String ipl { get; set; }
        public Vector3 position { get; set; }

        public BusinessIplModel(int type, String ipl, Vector3 position)
        {
            this.type = type;
            this.ipl = ipl;
            this.position = position;
        }
    }
}
