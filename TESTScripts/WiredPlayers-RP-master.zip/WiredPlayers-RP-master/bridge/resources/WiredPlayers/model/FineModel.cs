﻿using System;

namespace WiredPlayers.model
{
    public class FineModel
    {
        public String officer { get; set; }
        public String target { get; set; }
        public int amount { get; set; }
        public String reason { get; set; }
        public String date { get; set; }
    }
}
