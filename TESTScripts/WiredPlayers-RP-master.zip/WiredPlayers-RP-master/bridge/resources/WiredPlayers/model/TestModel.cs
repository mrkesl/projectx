﻿using System;

namespace WiredPlayers.model
{
    public class TestModel
    {
        public int id { get; set; }
        public String text { get; set; }
        public int question { get; set; }
    }
}
