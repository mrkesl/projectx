﻿namespace WiredPlayers.model
{
    public class ParkedCarModel
    {
        public int parkingId { get; set; }
        public VehicleModel vehicle { get; set; }
    }
}
