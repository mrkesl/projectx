To see how this resource works visit;
https://wiki.gtanet.work/index.php?title=Getting_started_with_Basic_Vehicle_Sync_Resource