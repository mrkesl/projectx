This resource will make vehicle acceleration smoother so you don't skid the tires.

This resource also includes anti-reverse braking.
That means when you brake, you will come to a stop but you will not reverse until you release and press the reverse button again. Automatic brake lights included.