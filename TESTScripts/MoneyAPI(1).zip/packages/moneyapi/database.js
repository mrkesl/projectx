const mysql = require("mysql");
const constants = require("./constants");

module.exports = {
    Pool: null,
    Connect: function(callback) {
        this.Pool = mysql.createPool({
            host: constants.mysqlHost,
            user: constants.mysqlUser,
            password: constants.mysqlPass,
            database: constants.mysqlDatabase
        });

        this.Pool.getConnection((err, conn) => {
            if (!err) {
                console.log(`${constants.infoPre} Connected to database.`);
                callback();
            } else {
                console.log(constants.initErrorPre + err.message);
            }

            conn.release();
        });
    }
};