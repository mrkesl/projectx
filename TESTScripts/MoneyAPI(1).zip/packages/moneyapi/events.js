const DB = require("./database");
const constants = require("./constants");

mp.events.add("playerJoin", (player) => {
    DB.Pool.query("SELECT Money FROM mdb_players WHERE Name=? LIMIT 1", [player.name], (err, rows) => {
        if (err) {
            console.log(constants.eventErrorPre + err.message);
        } else {
            if (rows.length > 0) {
                player.data.customMoney = rows[0].Money;
            } else {
                DB.Pool.query("INSERT INTO mdb_players SET Name=?, Money=?", [player.name, constants.startingMoney], (regErr) => {
                    if (regErr) {
                        console.log(constants.eventErrorPre + regErr.message);
                    } else {
                        player.data.customMoney = constants.startingMoney;
                    }
                });
            }
        }
    });
});

mp.events.add("playerQuit", (player, exitType, reason) => {
    if (player.data.customMoney !== undefined) {
        DB.Pool.query("UPDATE mdb_players SET Money=? WHERE Name=?", [player.data.customMoney, player.name], (err) => {
            if (err) console.log(constants.eventErrorPre + err.message);
        });
    }
});