module.exports = {
    // database
    mysqlHost: "mysql host", // do not use ip address as a host, create a dns if your mysql server is not hosted on same server/machine as ragemp server
    mysqlUser: "mysql user",
    mysqlPass: "mysql password",
    mysqlDatabase: "mysql database name",

    // settings
    startingMoney: 0, // how much money players start with
    autoSaveInterval: 5, // minutes, 0 to disable

    // messages
    infoPre: "\x1b[92m[MoneyAPI]\x1b[0m",
    initErrorPre: "\x1b[91m[MoneyAPI Init Error] \x1b[0m",
    eventErrorPre: "\x1b[91m[MoneyAPI Event Error] \x1b[0m",
    autoSaveErrorPre: "\x1b[91m[MoneyAPI Autosave Error] \x1b[0m",
};