const DB = require("./database");
const constants = require("./constants");

DB.Connect(() => {
    DB.Pool.query("CREATE TABLE IF NOT EXISTS `mdb_players` (`ID` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY, `Name` varchar(24) NOT NULL, `Money` int(11) NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8;", (err) => {
        if (err) console.log(constants.initErrorPre + err.message);
    });

    console.log(`${constants.infoPre} Starting money: $${constants.startingMoney}`);
    console.log(`${constants.infoPre} Autosave: ${constants.autoSaveInterval > 0 ? `Every ${constants.autoSaveInterval} minutes` : "Disabled"}`);

    if (constants.autoSaveInterval > 0) {
        setInterval(() => {
            mp.players.forEach((player) => {
                if (player.data.customMoney !== undefined) {
                    DB.Pool.query("UPDATE mdb_players SET Money=? WHERE Name=?", [player.data.customMoney, player.name], (saveErr) => {
                        if (saveErr) console.log(constants.autoSaveErrorPre + saveErr.message);
                    });
                }
            });
        }, constants.autoSaveInterval * 60000);
    }
});

require("./events");